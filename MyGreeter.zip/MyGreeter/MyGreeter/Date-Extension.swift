//
//  Date-Extension.swift
//  KsaxProShop
//
//  Created by Mac on 2021/9/13.
//  Copyright © 2021 Mac. All rights reserved.
//

import UIKit

extension Date {
    func nowTime(_ dateFormat: String?) -> String {
        let currentDate = self
        let formatter = DateFormatter()
        formatter.dateFormat = dateFormat ?? "HH"
        let time = formatter.string(from: currentDate)
        return time
    }
    
    // MARK: 前一天的时间
    func getLastDay(_ dateFormat: String?) -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = dateFormat ?? "yyyy-MM-dd"
        
        let date = self
        let lastTime: TimeInterval = -(24*60*60) // 往前减去一天的秒数，昨天
        //        let nextTime: TimeInterval = 24*60*60 // 这是后一天的时间，明天
        
        let lastDate = date.addingTimeInterval(lastTime)
        let lastDay = dateFormatter.string(from: lastDate)
        return lastDay
    }
    
    // MARK: 获取某一天所在的周一和周日
    func getWeekTime(_ dateFormat: String?) -> [String] {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = dateFormat ?? "yyyy-MM-dd"
        
        let nowDate = self
        let calendar = Calendar.current
        let comp = calendar.dateComponents([.year, .month, .day, .weekday], from: nowDate)
        
        // 获取今天是周几
        let weekDay = comp.weekday
        // 获取几天是几号
        let day = comp.day
        
        // 计算当前日期和本周的星期一和星期天相差天数
        var firstDiff: Int
        var lastDiff: Int
        // weekDay = 1;
        if (weekDay == 1) {
            firstDiff = -6;
            lastDiff = 0;
        } else {
            firstDiff = calendar.firstWeekday - weekDay! + 1
            lastDiff = 8 - weekDay!
        }
        
        // 在当前日期(去掉时分秒)基础上加上差的天数
        var firstDayComp = calendar.dateComponents([.year, .month, .day], from: nowDate)
        firstDayComp.day = day! + firstDiff
        let firstDayOfWeek = calendar.date(from: firstDayComp)
        var lastDayComp = calendar.dateComponents([.year, .month, .day], from: nowDate)
        lastDayComp.day = day! + lastDiff
        let lastDayOfWeek = calendar.date(from: lastDayComp)
        
        let firstDay = dateFormatter.string(from: firstDayOfWeek!)
        let lastDay = dateFormatter.string(from: lastDayOfWeek!)
        let weekArr = [firstDay, lastDay]
        
        return weekArr;
    }
    
    // MARK: 当月开始日期
    func startOfCurrentMonth(_ dateFormat: String?) -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = dateFormat ?? "yyyy-MM-dd"
        let nowDayDate = self
        
        let calendar = Calendar.current
        let components = calendar.dateComponents([.year, .month], from: nowDayDate)
        let startOfMonth = calendar.date(from: components)
        
        let day = dateFormatter.string(from: startOfMonth!)
        return day
    }
    
    // MARK: 当月结束日期
    func endOfCurrentMonth(_ dateFormat: String?, returnEndTime:Bool = false) -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = dateFormat ?? "yyyy-MM-dd"
        let nowDayDate = self
        
        let calendar = Calendar.current
        var components = DateComponents()
        components.month = 1
        if returnEndTime {
            components.second = -1
        } else {
            components.day = -1
        }
        //startOfCurrentMonth
        let currentMonth = calendar.dateComponents([.year, .month], from: nowDayDate)
        let startOfMonth = calendar.date(from: currentMonth)
        let endOfMonth = calendar.date(byAdding: components, to: startOfMonth!)
        
        let day = dateFormatter.string(from: endOfMonth!)
        return day
    }
}
