//
//  MyGreeter.swift
//  MyGreeter
//
//  Created by 孙兆培 on 2022/6/14.
//

import UIKit

class MyGreeter: NSObject {
    
    func Client()->String{
        let date = NSDate()

        let timeFormatter = DateFormatter()

        timeFormatter.dateFormat = "HH"

        var  strNowTime = timeFormatter.string(from: date as Date)
        
        var des = ""
        var intFlag = Int(strNowTime) ?? 0
        
        if  6 < intFlag  && intFlag < 12 {
            des = "早上好"
        }else if 12 <= intFlag && intFlag < 18 {
            des = "下午好"
        }else if 18 <= intFlag{
            des = "晚上好"
        }
        return des

    }

}
